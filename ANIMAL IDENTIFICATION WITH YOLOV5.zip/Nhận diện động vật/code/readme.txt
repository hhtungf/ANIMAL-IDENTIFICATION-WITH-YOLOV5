b1:tạo project
b2:copy 3 file(detect.py,requirements.txt,yolov5) vào project
b3:xóa file best.pt cũ trong file yolov5 và cho file best.pt mới vào đó
b4:run project  